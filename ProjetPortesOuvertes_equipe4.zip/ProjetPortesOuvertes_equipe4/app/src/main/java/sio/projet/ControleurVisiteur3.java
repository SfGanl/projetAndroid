package sio.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import plum.widget.ComboDialog;

public class ControleurVisiteur3 extends AppCompatActivity implements
        ComboDialog.OnClickComboDialogListener, View.OnClickListener {
String item = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controleur_visiteur3);

        TextView myTextViewItem = (TextView) findViewById( R.id.item );

        final CharSequence[] items = {"Commerce international","Commerce internet","Finance"};
        final CharSequence[] values = {"1","2","3"};

        ComboDialog comboDiplome = new ComboDialog("Choisir votre diplome",
                items,
                values,
                myTextViewItem,
                this);

        Button btn_terminer = (Button) findViewById(R.id.btn_terminer);

        btn_terminer.setOnClickListener(this);
        comboDiplome.setOnClickComboDialogListener(this);
    }

    @Override
    public void onClickComboDialog(ComboDialog comboDialog) {
        item = (String) comboDialog.item( comboDialog.getIndexSelected());
    }

    @Override
    public void onClick(View view) {
        if(!item.equals("")){
            PorteOuverteSQLLite ajout = new PorteOuverteSQLLite(this);
            Visiteur newVisiteur = new Visiteur();
            newVisiteur.nom = getIntent().getStringExtra("nomVisiteur.texte");
            newVisiteur.prenom = getIntent().getStringExtra("prenomVisiteur.texte");
            newVisiteur.telephone = Integer.parseInt(getIntent().getStringExtra("telephoneVisiteur.texte"));
            newVisiteur.etablissement = getIntent().getStringExtra("etablissement.texte");
            newVisiteur.baccalaureat = getIntent().getStringExtra("diplome.texte");
            newVisiteur.specialite = item;

            ajout.putVisiteur(newVisiteur);
            finish();
        }else{
            Toast.makeText(getApplicationContext(), "Vous devez choisir une spécialité", Toast.LENGTH_SHORT).show();
        }
    }
}