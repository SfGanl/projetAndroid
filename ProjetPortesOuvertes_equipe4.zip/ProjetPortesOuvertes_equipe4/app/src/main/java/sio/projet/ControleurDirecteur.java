package sio.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import plum.widget.ComboDialog;

public class ControleurDirecteur extends AppCompatActivity implements AdapterView.OnItemClickListener,
        View.OnClickListener, ComboDialog.OnClickComboDialogListener {
    ArrayList<Visiteur> lesvisiteurs = new ArrayList<Visiteur>();
    ArrayAdapter<Visiteur> arrayAdapterVisiteur;
    Visiteur levisiteur = new Visiteur();
    PorteOuverteSQLLite VisiteurArrayAdapter = new PorteOuverteSQLLite(this);
    ListView lv;
    String valeur1 = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controleur_directeur);
        lesvisiteurs = VisiteurArrayAdapter.getListeVisiteur();
        arrayAdapterVisiteur = new VisiteurArrayAdapter(this, lesvisiteurs);
        lv = findViewById(R.id.list);
        lv.setAdapter(arrayAdapterVisiteur);
        Button btn_retour = (Button) findViewById(R.id.btn_retourmenu);
        Button btn_filtre = (Button) findViewById(R.id.btn_filtre);
        Button btn_reafiltre = (Button) findViewById(R.id.btn_reafiltre);
        btn_retour.setOnClickListener(this);
        btn_filtre.setOnClickListener(this);
        btn_reafiltre.setOnClickListener(this);
        lv.setOnItemClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_retourmenu:
                Intent retour = new Intent(this, MainActivity.class);
                startActivity(retour);
                break;
            case R.id.btn_reafiltre:
                lesvisiteurs = VisiteurArrayAdapter.getListeVisiteurPara("Tous", "Tous");
                arrayAdapterVisiteur = new VisiteurArrayAdapter(this, lesvisiteurs);
                lv.setAdapter(arrayAdapterVisiteur);
                break;
            case R.id.btn_filtre:
                final CharSequence[] items2 = {"Commerce international","Commerce internet","Finance", "Tous"};
                final CharSequence[] values2 = {"7","8","9","10"};

                ComboDialog comboSpecialite = new ComboDialog("Choisir la spécialitée",
                        items2,
                        values2,
                        null,
                        this);
                comboSpecialite.show();
                final CharSequence[] items = {"Bac general","Bac technologique","Bac professionnel", "Universite", "Autre", "Tous"};
                final CharSequence[] values = {"0","1","2","3","4","5","6"};
                ComboDialog comboOrigine = new ComboDialog("Choisir l'origine",
                        items,
                        values,
                        null,
                        this);
                comboOrigine.show();
                comboOrigine.setOnClickComboDialogListener(this);
                comboSpecialite.setOnClickComboDialogListener(this);
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        levisiteur = (Visiteur) adapterView.getItemAtPosition(i);
        final CharSequence[] items = {"Neutre","Favorable","Défavorable", "Appeler"};
        final CharSequence[] values = {"11","12","13", "14"};

        ComboDialog comboAvis = new ComboDialog("Choisir votre avis",
                items,
                values,
                null,
                this);
        comboAvis.show();
        comboAvis.setOnClickComboDialogListener(this);
    }


    @Override
    public void onClickComboDialog(ComboDialog comboDialog) {
        String value = (String) comboDialog.value( comboDialog.getIndexSelected());
        PorteOuverteSQLLite ajout = new PorteOuverteSQLLite(this);

        switch (value){
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
                valeur1 = (String) comboDialog.item(comboDialog.getIndexSelected());
                break;
            case "7":
            case "8":
            case "9":
            case "10":
                String valeur2 = (String) comboDialog.item(comboDialog.getIndexSelected());
                lesvisiteurs = VisiteurArrayAdapter.getListeVisiteurPara(valeur2, valeur1);
                arrayAdapterVisiteur = new VisiteurArrayAdapter(this, lesvisiteurs);
                lv.setAdapter(arrayAdapterVisiteur);
                break;
            case "11":
                levisiteur.avis = 0;
                ajout.updateAvisVisiteur(levisiteur);
                break;
            case "12":
                levisiteur.avis = 1;
                ajout.updateAvisVisiteur(levisiteur);
                break;
            case "13":
                levisiteur.avis = 2;
                ajout.updateAvisVisiteur(levisiteur);
                break;
            case "14":
                Intent intent = new Intent(Intent.ACTION_DIAL);
                String uri = "tel:" + levisiteur.telephone;
                intent.setData(Uri.parse(uri));
                startActivity(intent);
        }
        arrayAdapterVisiteur.notifyDataSetChanged();
    }
}