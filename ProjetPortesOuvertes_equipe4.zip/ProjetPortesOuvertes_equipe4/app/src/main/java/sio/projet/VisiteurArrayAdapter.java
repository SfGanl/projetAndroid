package sio.projet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class VisiteurArrayAdapter extends ArrayAdapter<Visiteur> {

    public VisiteurArrayAdapter(Context context, ArrayList<Visiteur> lesvisiteurs) {
        super(context, 0, lesvisiteurs);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Visiteur visiteur = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_fiche,
                    parent,
                    false);
        }

        TextView txtNom = (TextView) convertView.findViewById(R.id.txtNom);
        TextView txtPrenom = (TextView) convertView.findViewById(R.id.txtPrenom);
        TextView txtEtablissement = (TextView) convertView.findViewById(R.id.txtEtablissement);
        TextView txtBaccalaureat = (TextView) convertView.findViewById(R.id.txtBaccalaureat);
        TextView txtSpecialite = (TextView) convertView.findViewById(R.id.txtSpecialite);
        TextView txtTel = (TextView) convertView.findViewById(R.id.txtTelephone);
        txtNom.setText(visiteur.nom);
        txtPrenom.setText(visiteur.prenom);
        txtEtablissement.setText(visiteur.etablissement);
        txtBaccalaureat.setText(visiteur.baccalaureat);
        txtSpecialite.setText(visiteur.specialite);
        txtTel.setText(visiteur.telephone + "");
        ImageView imageView = (ImageView) convertView.findViewById(R.id.neutre);
            if (visiteur.avis == 0){
                imageView.setImageResource(R.mipmap.neutre);
            } else if (visiteur.avis == 1){
                imageView.setImageResource(R.mipmap.favorable);
            } else if (visiteur.avis == 2){
                imageView.setImageResource(R.mipmap.defavorable);
            }

        return convertView;
        }

    }



