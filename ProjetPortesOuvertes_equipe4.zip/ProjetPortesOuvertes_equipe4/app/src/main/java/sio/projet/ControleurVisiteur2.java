package sio.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import plum.widget.ComboDialog;

public class ControleurVisiteur2 extends AppCompatActivity implements
        ComboDialog.OnClickComboDialogListener, View.OnClickListener{

String item = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controleur_visiteur2);

        TextView myTextViewItem = (TextView) findViewById( R.id.item );

        final CharSequence[] items = {"Bac général","Bac technologique","Bac professionnel","Université","Autre"};
        final CharSequence[] values = {"1","2","3","4","5"};

        ComboDialog comboDiplome = new ComboDialog("Choisir votre diplome",
                items,
                values,
                myTextViewItem,
                this);

        Button btn_suivant = (Button) findViewById(R.id.btn_suivantVisiteur2);

        comboDiplome.setOnClickComboDialogListener(this);
        btn_suivant.setOnClickListener(this);

    }

    @Override
    public void onClickComboDialog(ComboDialog comboDialog) {
        String value = (String) comboDialog.value( comboDialog.getIndexSelected());
        EditText edtInformation = (EditText) findViewById(R.id.information);
        item = (String) comboDialog.item(comboDialog.getIndexSelected());

        switch (value){
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
            edtInformation.setFocusable(true);
            edtInformation.setHint("Nom de l'établissement");
            edtInformation.setText("");
            break;
        default: edtInformation.setFocusable(false);
    }
}

    @Override
    public void onClick(View view) {
        EditText edtInformation = (EditText) findViewById(R.id.information);

        if(!item.equals("") && !edtInformation.getText().toString().equals("")){
            Intent intentVisiteurSpecialisation = new Intent(this, ControleurVisiteur3.class);

            intentVisiteurSpecialisation.putExtra("nomVisiteur.texte",getIntent().getStringExtra("nomVisiteur.texte"));
            intentVisiteurSpecialisation.putExtra("prenomVisiteur.texte",getIntent().getStringExtra("prenomVisiteur.texte"));
            intentVisiteurSpecialisation.putExtra("telephoneVisiteur.texte",getIntent().getStringExtra("telephoneVisiteur.texte"));
            intentVisiteurSpecialisation.putExtra("etablissement.texte",edtInformation.getText().toString());
            intentVisiteurSpecialisation.putExtra("diplome.texte",item);
            finish();
            startActivity(intentVisiteurSpecialisation);
        }else{
            int red = Color.parseColor("#FF0000");
            edtInformation.setBackgroundColor(red);
            Toast.makeText(getApplicationContext(), "Erreur: un champ doit être rempli", Toast.LENGTH_SHORT).show();
        }
    }
}