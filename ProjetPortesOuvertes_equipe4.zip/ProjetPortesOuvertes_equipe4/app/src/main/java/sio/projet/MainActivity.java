package sio.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ecouteur
        Button btn_visiteur = (Button) findViewById(R.id.btn_visiteur);
        Button btn_directeur = (Button) findViewById(R.id.btn_directeur);

        btn_visiteur.setOnClickListener(this);
        btn_directeur.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_visiteur:
                Intent intentVisiteur = new Intent(this,ControleurVisiteur.class);
                startActivity(intentVisiteur);
                break;
            case R.id.btn_directeur:
                Intent intentDirecteur = new Intent(this,ControleurDirecteur.class);
                startActivity(intentDirecteur);
                break;
        }
    }
}
