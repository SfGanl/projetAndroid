package sio.projet;

public class Visiteur {
    public int id;
    public String nom;
    public String prenom;
    public String baccalaureat;
    public String etablissement;
    public String specialite;
    public int avis;
    public int telephone;


}
