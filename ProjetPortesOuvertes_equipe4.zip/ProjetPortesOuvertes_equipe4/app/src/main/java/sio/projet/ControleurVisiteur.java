package sio.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ControleurVisiteur extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controleur_visiteur);

        Button btn_suivant = (Button) findViewById(R.id.btn_suivantVisiteur1);
        btn_suivant.setOnClickListener(this);
        Button btn_retour = (Button) findViewById(R.id.btn_retourmenu);
        btn_retour.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_retourmenu:
                Intent retour = new Intent(this,MainActivity.class);
                startActivity(retour);
                break;
            case R.id.btn_suivantVisiteur1:
                // Champs texte
                EditText nom = (EditText) findViewById(R.id.nom);
                EditText prenom = (EditText) findViewById(R.id.prenom);
                EditText tel = (EditText) findViewById(R.id.numtel);

                // Couleur
                int red = Color.parseColor("#FF0000");
                int blanc = Color.parseColor("#FFFFFF");

                //Verification des champs remplis
                if(prenom.getText().toString().equals("")) {
                    prenom.setBackgroundColor(red);
                    Toast.makeText(getApplicationContext(), "un/des champs ne sont pas rempli", Toast.LENGTH_SHORT).show();
                }else{prenom.setBackgroundColor(blanc);}

                if(nom.getText().toString().equals("")){
                    nom.setBackgroundColor(red);
                    Toast.makeText(getApplicationContext(), "un/des champs ne sont pas rempli", Toast.LENGTH_SHORT).show();
                }else{nom.setBackgroundColor(blanc);}

                if(tel.getText().toString().equals("")){
                    tel.setBackgroundColor(red);
                    Toast.makeText(getApplicationContext(), "un/des champs ne sont pas rempli", Toast.LENGTH_SHORT).show();
                }else{tel.setBackgroundColor(blanc);}

                if(!nom.getText().toString().equals("") & !prenom.getText().toString().equals("") & !tel.getText().toString().equals("")){
                    Intent intentVisiteurDiplome = new Intent(this,ControleurVisiteur2.class);
                    intentVisiteurDiplome.putExtra("nomVisiteur.texte",nom.getText().toString());
                    intentVisiteurDiplome.putExtra("prenomVisiteur.texte",prenom.getText().toString());
                    intentVisiteurDiplome.putExtra("telephoneVisiteur.texte",tel.getText().toString());

                    startActivity(intentVisiteurDiplome);
                }
        }



    }
}